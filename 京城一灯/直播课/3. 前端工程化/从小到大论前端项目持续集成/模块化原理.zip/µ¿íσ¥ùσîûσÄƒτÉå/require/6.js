


define(['5.js'], function(a) {
	console.log('6.js loaded', a)
	return '6.js return'
})