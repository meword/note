

// 2.js
define(['4.js'], function(a) {
	console.log('2.js loaded', a)
	return '2.js return'
})