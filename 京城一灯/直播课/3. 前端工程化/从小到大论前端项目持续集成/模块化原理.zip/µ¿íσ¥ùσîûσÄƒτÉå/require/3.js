


define([], function() {
	console.log('3.js loaded')
	return '3.js return'
})
