



define([],function() {
	console.log('5.js loaded')
	return '5.js return'
})