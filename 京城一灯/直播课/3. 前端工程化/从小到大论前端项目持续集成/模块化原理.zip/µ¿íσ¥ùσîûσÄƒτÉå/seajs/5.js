



define(function() {
	console.log('5.js执行了')
	return '5.js return'
})