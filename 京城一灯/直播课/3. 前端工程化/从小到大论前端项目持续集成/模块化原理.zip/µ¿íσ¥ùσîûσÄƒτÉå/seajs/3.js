


define(function() {
	console.log('3.js执行了')
	return '3.js return'
})
