import "./navigation.css";
const navigation ={
    init(){
        console.log("navigation组件对应的入口文件");
    }
}
export default navigation;