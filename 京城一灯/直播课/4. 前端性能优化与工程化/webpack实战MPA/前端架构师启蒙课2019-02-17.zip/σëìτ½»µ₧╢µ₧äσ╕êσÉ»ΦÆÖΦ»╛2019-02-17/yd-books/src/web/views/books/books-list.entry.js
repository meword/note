import list from "../../components/list/list.js";
import navigation from "../../components/navigation/navigation.js";
navigation.init();
list.init();