import "./list.css";
const list ={
    init(){
        console.log("list组件对应的入口文件");
    }
}
export default list;