import "./add.css";
const add ={
    init(){
        console.log("add组件对应的入口文件");
    }
}
export default add;