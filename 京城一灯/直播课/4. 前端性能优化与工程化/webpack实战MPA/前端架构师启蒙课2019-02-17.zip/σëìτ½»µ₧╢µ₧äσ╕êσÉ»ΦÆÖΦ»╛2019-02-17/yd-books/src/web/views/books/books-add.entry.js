import add from "../../components/add/add.js";
import navigation from "../../components/navigation/navigation.js";
navigation.init();
add.init();